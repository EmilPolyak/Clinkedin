(function () {
  'use strict';
  if (!/(^|\.)linkedin\.com$/i.test(location.hostname) || globalThis.__clinkedin) return;
  globalThis.__clinkedin = true;
  const S = ClinkedinSettings, E = ClinkedinEngine;
  const D = ClinkedinDOM;
  const POST = D.POST;
  const UI = '[data-clinkedin-ui]';
  let settings = S.normalize(), records = new Map(), toolbar, timer, force = false, pending = new Map(), revealAll = false;
  let layoutNodes = new Set(), lastError = '', scans = 0, work = new Set();
  let settingsRevision = 0, available = false, stopped = false;
  const inFeed = () => /^\/feed\/?$/.test(location.pathname);
  const observer = new MutationObserver(mutations => {
    if (!inFeed()) return;
    for (const m of mutations) {
      const target = m.target.nodeType === 1 ? m.target : m.target.parentElement;
      if (!target || target.closest(`${UI}, ${D.COMMENTS}, ${D.MEDIA}, input, [role="slider"], [role="progressbar"]`) || (target.closest('button') && !D.relationshipControl(target))) continue;
      const card = D.outer(target);
      if (m.type === 'characterData') {
        if (target.closest(`${D.BODY}, ${D.META}`) || D.relationshipControl(target)) pending.set(card || target, false);
        continue;
      }
      if (m.type === 'attributes') { pending.set(card || target, !card); continue; }
      if (card) {
        const changed = [...m.addedNodes, ...m.removedNodes].filter(n => n.nodeType === 1);
        const contentChange = target.closest(`${D.BODY}, ${D.META}`) || D.relationshipControl(target) || changed.some(n => n.matches(`${D.BODY}, ${D.META}`) || n.querySelector(`${D.BODY}, ${D.META}`) || D.relationshipControl(n));
        const newMedia = changed.some(n => n.matches('video, img') || n.querySelector('video, img')) && !records.get(card)?.types?.includes('videos');
        if (contentChange || newMedia || !records.has(card)) pending.set(card, false);
      } else {
        // Discover only new branches; do not rescan the feed because a player
        // changed one of its counters or controls.
        for (const node of m.addedNodes) if (node.nodeType === 1 && !node.matches(`${UI}, ${D.COMMENTS}`)) pending.set(node, true);
        if (m.removedNodes.length) pending.set(target, false);
      }
    }
    if (pending.size) schedule();
  });
  function observe() {
    // Video controls continuously rewrite classes/styles. They are not post identity.
    if (!stopped) observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['data-urn', 'data-id', 'componentkey', 'data-testid', 'role', 'href', 'alt', 'src', 'aria-label', 'id'] });
  }
  function schedule(full = false, delay = 160) {
    force ||= full;
    if (!timer && !stopped) timer = setTimeout(run, delay);
  }
  function element(tag, content, className) {
    const node = document.createElement(tag);
    if (content) node.textContent = content;
    if (className) node.className = className;
    return node;
  }
  function own(node) { node.setAttribute('data-clinkedin-ui', ''); return node; }
  function button(label, action) { const b = element('button', label); b.type = 'button'; b.addEventListener('click', action); return b; }
  function restore(node, record) {
    node.removeAttribute('data-clinkedin-hidden');
    record.placeholder?.remove(); record.mute?.remove();
    record.placeholder = record.mute = null;
  }
  function cleanup() {
    for (const [node, record] of records) restore(node, record);
    records.clear(); work.clear(); toolbar?.remove(); toolbar = null; available = false;
    for (const node of layoutNodes) node.removeAttribute('data-clinkedin-layout-hidden');
    layoutNodes.clear();
    ClinkedinLayout.clear();
    document.documentElement.removeAttribute('data-clinkedin-layout');
  }
  async function mute(author) {
    try { const latest = await S.load(); latest.authors = S.list([...latest.authors, author]); await S.save(latest); }
    catch { if (toolbar) toolbar.title = 'Unable to save. Reload LinkedIn after reloading the extension.'; }
  }
  function apply(node) {
    const data = D.extract(node);
    const identity = JSON.stringify([node.getAttribute('data-urn') || node.getAttribute('data-id') || node.getAttribute('componentkey'), data]);
    let record = records.get(node);
    if (!record) { record = {}; records.set(node, record); }
    if (record.identity !== identity || record.revision !== settingsRevision) record.visibility = null;
    record.identity = identity; record.revision = settingsRevision;
    record.types = data.types;
    record.reasons = E.evaluate(data, settings);
    record.author = data.author;
    const hidden = record.reasons.length > 0 && (record.visibility === 'hide' || (record.visibility !== 'show' && !revealAll));
    if (node.hasAttribute('data-clinkedin-hidden') !== hidden) node.toggleAttribute('data-clinkedin-hidden', hidden);
    if (record.reasons.length && settings.showPlaceholders) {
      if (!record.placeholder) {
        const box = own(element('div', '', 'clinkedin-placeholder'));
        const label = element('span');
        const reveal = button('Show post', () => {
          record.visibility = node.hasAttribute('data-clinkedin-hidden') ? 'show' : 'hide';
          pending.set(node, false); schedule();
        });
        box.append(label, reveal); record.placeholder = box;
      }
      const label = record.placeholder.firstChild;
      const description = `${record.reasons[0]}${record.reasons.length > 1 ? ` +${record.reasons.length - 1} more` : ''}`;
      setText(label, `${hidden ? 'Filtered' : 'Shown'} · ${description}`);
      setText(record.placeholder.lastChild, hidden ? 'Show post' : 'Hide post');
      if (record.placeholder.lastChild.getAttribute('aria-expanded') !== String(!hidden)) record.placeholder.lastChild.setAttribute('aria-expanded', String(!hidden));
      record.placeholder.title = record.reasons.join('\n');
      if (node.previousElementSibling !== record.placeholder) node.before(record.placeholder);
    } else { record.placeholder?.remove(); record.placeholder = null; }
    if (settings.enabled && settings.showMuteButtons && data.author && !hidden) {
      if (!record.mute || record.mute.dataset.author !== data.author) {
        record.mute?.remove(); record.mute = own(button(`Mute ${data.author}`, () => mute(data.author)));
        record.mute.className = 'clinkedin-mute'; record.mute.dataset.author = data.author;
        node.append(record.mute);
      }
    } else { record.mute?.remove(); record.mute = null; }
  }
  function stats() {
    return { inFeed: inFeed(), enabled: settings.enabled, scanned: records.size, matched: [...records.values()].filter(r => r.reasons.length).length,
      hidden: [...records.keys()].filter(n => n.hasAttribute('data-clinkedin-hidden')).length, available, revealAll,
      version: chrome.runtime.getManifest().version, error: lastError, scans,
      layout: document.querySelector('[data-testid="mainFeed"]') ? 'current' : 'classic',
      feedFound: !!document.querySelector(`${D.FEED}, main, [role="main"]`), layoutHidden: layoutNodes.size };
  }
  function toggleRevealAll() {
    revealAll = !revealAll;
    for (const record of records.values()) record.visibility = null;
    schedule(true);
  }
  function updateToolbar() {
    if (!settings.showToolbar) { toolbar?.remove(); toolbar = null; return; }
    const anchor = records.keys().next().value || document.querySelector(`${D.FEED}, main, [role="main"]`);
    if (!anchor) return;
    if (!toolbar?.isConnected) {
      toolbar = own(element('div', '', 'clinkedin-toolbar'));
      toolbar.append(element('strong', 'Clinkedin'), element('span'),
        button('', toggleRevealAll),
        button('', async () => { try { const latest = await S.load(); latest.enabled = !latest.enabled; await S.save(latest); } catch { toolbar.title = 'Could not save. Reload this tab.'; } }),
        button('Settings ↗', () => chrome.runtime.sendMessage({ action: 'openSettings' }).catch(() => {})));
      anchor.before(toolbar);
    }
    const count = stats();
    setText(toolbar.children[1], lastError ? 'Filter error. Open Clinkedin for details.' : !count.scanned ? 'No supported posts detected' : settings.enabled ? `${count.hidden} of ${count.scanned} filtered` : 'Filtering paused');
    setText(toolbar.children[2], revealAll ? 'Apply filters' : 'Reveal filtered');
    if (toolbar.children[2].getAttribute('aria-pressed') !== String(revealAll)) toolbar.children[2].setAttribute('aria-pressed', String(revealAll));
    setText(toolbar.children[3], settings.enabled ? 'Pause' : 'Resume');
  }
  function setText(node, value) { if (node.textContent !== value) node.textContent = value; }
  function run() {
    timer = null; if (stopped) return;
    observer.disconnect();
    try {
      scans++;
      if (!inFeed()) { cleanup(); pending.clear(); force = false; return; }
      const flags = settings.enabled ? Object.entries(settings.layout).filter(([,v]) => v).map(([k]) => k) : [];
      if (document.documentElement.getAttribute('data-clinkedin-layout') !== flags.join(' ')) document.documentElement.setAttribute('data-clinkedin-layout', flags.join(' '));
      const nextLayoutNodes = D.layoutTargets(settings);
      ClinkedinLayout.apply(settings, nextLayoutNodes);
      for (const node of layoutNodes) if (!nextLayoutNodes.has(node)) node.removeAttribute('data-clinkedin-layout-hidden');
      for (const node of nextLayoutNodes) if (!node.hasAttribute('data-clinkedin-layout-hidden')) node.setAttribute('data-clinkedin-layout-hidden', '');
      layoutNodes = nextLayoutNodes;
      const candidates = new Set();
      if (force) D.posts(document).forEach(n => candidates.add(n));
      else for (const [node, deep] of pending) {
        if (!node.isConnected) continue;
        D.posts(node, deep).forEach(n => candidates.add(n));
      }
      // An occludable wrapper and its activity card represent a single post.
      for (const node of [...candidates]) {
        let outer = node;
        while (outer.parentElement?.closest(POST)) outer = outer.parentElement.closest(POST);
        candidates.delete(node); candidates.add(outer);
      }
      for (const [node, record] of records) if (!node.isConnected || node.parentElement?.closest(POST)) { restore(node, record); records.delete(node); }
      for (const node of candidates) work.add(node);
      const started = performance.now();
      for (const node of work) {
        work.delete(node); if (node.isConnected) apply(node);
        if (performance.now() - started > 8) break;
      }
      lastError = '';
      available = records.size > 0; updateToolbar();
    } catch {
      lastError = 'A feed update could not be processed. Reload this tab after reloading Clinkedin in chrome://extensions.';
    } finally { pending.clear(); force = false; observe(); if (work.size) schedule(false, 16); }
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings) { settings = S.normalize(changes.settings.newValue); settingsRevision++; revealAll = false; schedule(true); }
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message?.action === 'stats') reply(stats());
    if (message?.action === 'reveal') { toggleRevealAll(); reply({ ok: true }); }
    if (message?.action === 'rescan') { schedule(true); reply({ ok: true }); }
  });
  let previousURL = location.href;
  const navigationTimer = setInterval(() => {
    if (previousURL !== location.href) { previousURL = location.href; revealAll = false; schedule(true); }
  }, 1000);
  addEventListener('pagehide', event => { if (!event.persisted) clearInterval(navigationTimer); });
  S.load().then(value => { if (!settingsRevision) settings = value; schedule(true); }).catch(() => {
    lastError = 'Saved settings could not be loaded. Reload Clinkedin in chrome://extensions, then refresh LinkedIn.';
    stopped = true; clearInterval(navigationTimer); observer.disconnect(); cleanup();
  });
})();
