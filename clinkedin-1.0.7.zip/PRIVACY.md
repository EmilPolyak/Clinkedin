# Clinkedin privacy statement

Last updated: October 28, 2026.

Clinkedin customizes the local display of the LinkedIn home feed and can disable automatic video playback across LinkedIn pages. It reads loaded feed-card text, visible author names, card structure, and links in order to apply the rules you select. That content is processed in your browser and is not stored or transmitted by the extension.

Your preferences, filter lists, optional muted-author names, and any additional followed-author names you enter are saved in Chrome's extension-local storage on your device. Connection filters read badges and follow-state labels from loaded feed cards; they do not fetch your contact graph or follow/unfollow accounts. Clinkedin does not send these settings or labels to a server, use Chrome sync storage, or share them with third parties. It has no analytics, advertising, remote code, external API calls, or tracking. LinkedIn's own website activity is independent of this extension.

Current feed counts, per-tab reveal choices, and manual video playback permissions exist only in memory. No post history, account credentials, cookies, messages, or browsing history are collected. Feed filtering runs only on the home feed. Autoplay control also runs on other HTTPS LinkedIn pages, matching LinkedIn frames, and their about:blank/srcdoc child frames; it does not request access to third-party websites.

Choosing Export downloads your current settings as a JSON file. You control where that file is stored and whether it is shared. Choosing Import reads only the file you select, then stages supported settings for review before saving. Neither operation uploads a file.

Only the autoplay enable/disable flag is passed to a page-context playback guard so it can prevent automatic video starts. Your filter lists and other saved preferences are not passed to that guard.

Use Reset settings and Save changes to remove your saved rules. Uninstalling the extension removes its Chrome extension-local storage; exported files remain wherever you saved them. Disabling or pausing the extension does not erase your preferences.
