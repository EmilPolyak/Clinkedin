(async function () {
  'use strict';
  const S = ClinkedinSettings, form = document.querySelector('#settings-form');
  const status = document.querySelector('#save-status'), saveButton = document.querySelector('#save-button');
  let baseline = '', ready = false, saving = false;
  function toggle(key, title, description, name) {
    const row = document.createElement('div'); row.className = 'toggle-item';
    const content = document.createElement('div'), label = document.createElement('strong'), help = document.createElement('p');
    label.id = `label-${key}`; label.textContent = title; help.id = `help-${key}`; help.textContent = description; content.append(label, help);
    const control = document.createElement('label'); control.className = 'switch';
    const input = document.createElement('input'); input.type = 'checkbox'; input.name = name;
    input.setAttribute('aria-labelledby', label.id); input.setAttribute('aria-describedby', help.id);
    control.append(input, document.createElement('span')); row.append(content, control); return row;
  }
  for (const [key, [title, help]] of Object.entries(S.TYPES)) document.querySelector('#types-list').append(toggle(key, title, help, `types.${key}`));
  for (const [key, [title, help]] of Object.entries(S.LAYOUT)) document.querySelector('#layout-list').append(toggle(key, title, help, `layout.${key}`));
  document.querySelector('#media-list').append(toggle('blockAutoplay', 'Disable video autoplay', 'Applies to all LinkedIn pages. Click Play to watch a video.', 'blockAutoplay'));
  const behavior = {
    showPlaceholders: ['Leave a placeholder', 'Show a reason bar with Show post / Hide post controls. Turn off to remove filtered posts completely.'],
    showToolbar: ['Show the feed toolbar', 'See a count of filtered posts and pause filters from the home feed.'],
    showMuteButtons: ['Show quick mute buttons', 'Add a local “Mute author” button to each visible post.']
  };
  for (const [key, [title, help]] of Object.entries(behavior)) document.querySelector('#behavior-list').append(toggle(key, title, help, key));
  function read() {
    const data = { types: {}, layout: {} };
    for (const control of form.elements) {
      if (!control.name) continue;
      const value = control.type === 'checkbox' ? control.checked : control.value;
      const [group, key] = control.name.split('.');
      if (key) data[group][key] = value; else data[group] = value;
    }
    return S.normalize(data);
  }
  function fill(settings) {
    for (const control of form.elements) {
      if (!control.name) continue;
      const [group, key] = control.name.split('.'); const value = key ? settings[group][key] : settings[group];
      if (control.type === 'checkbox') control.checked = value;
      else control.value = Array.isArray(value) ? value.join('\n') : value;
    }
    refresh();
  }
  function refresh(message) {
    const data = read(), types = Object.values(data.types).filter(Boolean).length;
    const count = ['keywords', 'allowKeywords', 'authors', 'allowedAuthors', 'domains', 'hashtags'].reduce((n, key) => n + data[key].length, 0) + types + Number(!!data.minWords) + Number(!!data.maxWords) + Number(data.connectionFilter !== 'all');
    document.querySelector('#active-count').textContent = count;
    document.querySelector('#type-count').replaceChildren(document.createTextNode(`${types} `), Object.assign(document.createElement('em'), { textContent: `/ ${Object.keys(S.TYPES).length}` }));
    document.querySelector('#keyword-count').textContent = data.keywords.length;
    document.querySelector('#filter-status').textContent = data.enabled ? 'Enabled' : 'Paused';
    status.textContent = message || (JSON.stringify(data) === baseline ? 'All changes saved' : 'Unsaved changes');
  }
  function valid() {
    const data = read();
    const max = form.elements.maxWords;
    max.setCustomValidity(data.maxWords && data.minWords > data.maxWords ? 'Maximum words must be at least the minimum, or 0 for no limit.' : '');
    return form.reportValidity();
  }
  form.addEventListener('input', () => { form.elements.maxWords.setCustomValidity(''); refresh(); });
  form.addEventListener('change', () => refresh());
  form.addEventListener('submit', async event => {
    event.preventDefault(); if (!ready || saving || !valid()) return;
    saving = true; saveButton.disabled = true; status.textContent = 'Saving…';
    try { const data = read(); await S.save(data); baseline = JSON.stringify(data); refresh(); }
    catch { status.textContent = 'Could not save settings. Your edits are still here; try again.'; }
    finally { saving = false; saveButton.disabled = false; }
  });
  document.querySelectorAll('[data-preset]').forEach(button => button.addEventListener('click', () => {
    if (!ready) return;
    const preset = button.dataset.preset;
    if (preset === 'clear') { document.querySelector('#reset-dialog').showModal(); return; }
    const data = read(); for (const key of ['sponsored', 'suggested', 'reactions']) data.types[key] = true;
    if (preset === 'focus') for (const key of ['hideRightRail', 'hideMetrics']) data.layout[key] = true;
    fill(data); refresh('Preset applied. Save to update your feed.');
  }));
  document.querySelector('#cancel-reset').addEventListener('click', () => document.querySelector('#reset-dialog').close());
  document.querySelector('#confirm-reset').addEventListener('click', () => { fill(S.normalize()); document.querySelector('#reset-dialog').close(); refresh('Defaults restored. Save to update your feed.'); });
  document.querySelector('#clear-types').addEventListener('click', () => { const data = read(); data.types = S.DEFAULTS.types; fill(data); });
  document.querySelector('#export').addEventListener('click', () => {
    if (!ready) return;
    const payload = { app: 'clinkedin', version: 1, settings: read() };
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = 'clinkedin-settings.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    document.querySelector('#tools-status').textContent = 'Exported current settings, including unsaved edits.';
  });
  document.querySelector('#import').addEventListener('change', async event => {
    const input = event.target, file = input.files[0], toolsStatus = document.querySelector('#tools-status'); if (!file || !ready) return;
    try {
      if (file.size > 1024 * 1024) throw new Error('Please use a settings file smaller than 1 MB.');
      const payload = JSON.parse(await file.text());
      if (payload?.app !== 'clinkedin' || payload.version !== 1 || !payload.settings || typeof payload.settings !== 'object' || Array.isArray(payload.settings)) throw new Error('Choose a version 1 Clinkedin settings export.');
      fill(S.normalize(payload.settings));
      toolsStatus.textContent = 'Backup loaded into the editor. Review and save to apply. Lists support 500 entries, up to 300 characters each.';
    } catch (error) { toolsStatus.textContent = error instanceof SyntaxError ? 'This file is not valid JSON. Choose a Clinkedin settings export.' : error.message; }
    finally { input.value = ''; }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.settings || saving || !ready) return;
    if (JSON.stringify(read()) !== baseline) { refresh('Settings changed in another tab. Save your edits to replace them.'); return; }
    const data = S.normalize(changes.settings.newValue); baseline = JSON.stringify(data); fill(data);
  });
  const links = [...document.querySelectorAll('nav a')];
  const sectionObserver = new IntersectionObserver(entries => {
    for (const entry of entries) if (entry.isIntersecting) for (const link of links) {
      const active = link.hash === `#${entry.target.id}`; link.classList.toggle('active', active);
      if (active) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current');
    }
  }, { rootMargin: '-10% 0px -65% 0px' });
  document.querySelectorAll('main section[id]').forEach(section => sectionObserver.observe(section));
  addEventListener('beforeunload', event => { if (ready && JSON.stringify(read()) !== baseline) { event.preventDefault(); event.returnValue = ''; } });
  try { const data = await S.load(); baseline = JSON.stringify(data); ready = true; fill(data); saveButton.disabled = false; }
  catch { status.textContent = 'Could not load settings. Reopen this page from the extension.'; }
})();
