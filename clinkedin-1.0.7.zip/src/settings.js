(function (root) {
  'use strict';
  const TYPES = {
    sponsored: ['Sponsored posts', 'Promoted posts and paid placements.'],
    suggested: ['Suggested posts', 'Recommendations outside your network.'],
    reposts: ['Reposts', 'Content someone else shared again.'],
    reactions: ['Network reactions', '“Liked this” and “commented on this” updates.'],
    hiring: ['Hiring & job posts', 'Job cards and posts with explicit hiring phrases.'],
    celebrations: ['Career celebrations', 'New roles, work anniversaries, and milestones.'],
    polls: ['Polls', 'Questions with a voting card.'],
    videos: ['Videos', 'Posts containing a video player.'],
    images: ['Images', 'Posts containing feed images; excludes avatars.'],
    documents: ['Documents & carousels', 'PDFs, presentations, and document viewers.'],
    articles: ['Articles & newsletters', 'LinkedIn articles and newsletter editions.'],
    events: ['Events', 'Posts with an event card or event link.'],
    links: ['External links', 'Posts linking outside LinkedIn.']
  };
  const LAYOUT = {
    hideRightRail: ['Hide right sidebar', 'Remove news, recommendations, and sidebar ads.'],
    hideLeftRail: ['Hide left sidebar', 'Remove your profile and shortcuts beside the feed.'],
    hideComposer: ['Hide post composer', 'Remove the “Start a post” box.'],
    hideMetrics: ['Hide engagement counts', 'Hide reaction and comment totals on posts.'],
    hidePostActions: ['Hide post action buttons', 'Hide Like, Comment, Repost, and Send buttons.'],
    wideFeed: ['Wider feed', 'Expand the feed column. Hiding sidebars frees more space.'],
    compactFeed: ['Compact spacing', 'Reduce space between feed cards.']
  };
  const DEFAULTS = {
    version: 1, enabled: true, blockAutoplay: false, keywords: [], allowKeywords: [], authors: [], allowedAuthors: [], domains: [], hashtags: [],
    matchMode: 'contains', caseSensitive: false, minWords: 0, maxWords: 0,
    connectionFilter: 'all', followedAuthors: [], keepUnknownConnections: false,
    types: Object.fromEntries(Object.keys(TYPES).map(k => [k, false])),
    layout: Object.fromEntries(Object.keys(LAYOUT).map(k => [k, false])),
    showPlaceholders: true, showToolbar: true, showMuteButtons: false
  };
  function list(value) {
    const lines = Array.isArray(value) ? value : typeof value === 'string' ? value.split(/\r?\n/) : [];
    return [...new Set(lines.filter(x => typeof x === 'string').map(x => x.trim().slice(0, 300)).filter(Boolean))].slice(0, 500);
  }
  function normalize(input = {}) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) input = {};
    const result = structuredClone(DEFAULTS);
    for (const key of ['enabled', 'blockAutoplay', 'caseSensitive', 'showPlaceholders', 'showToolbar', 'showMuteButtons', 'keepUnknownConnections']) {
      if (typeof input[key] === 'boolean') result[key] = input[key];
    }
    for (const key of ['keywords', 'allowKeywords', 'authors', 'allowedAuthors', 'domains', 'hashtags', 'followedAuthors']) result[key] = list(input[key]);
    result.connectionFilter = ['first-followed', 'first-second-followed'].includes(input.connectionFilter) ? input.connectionFilter : 'all';
    result.matchMode = input.matchMode === 'whole' ? 'whole' : 'contains';
    for (const key of ['minWords', 'maxWords']) result[key] = Math.max(0, Math.min(10000, Math.floor(Number(input[key]) || 0)));
    for (const group of ['types', 'layout']) for (const key of Object.keys(result[group])) {
      if (typeof input[group]?.[key] === 'boolean') result[group][key] = input[group][key];
    }
    return result;
  }
  const api = { TYPES, LAYOUT, DEFAULTS, list, normalize,
    async load() { return normalize((await chrome.storage.local.get('settings')).settings); },
    async save(settings) { const clean = normalize(settings); await chrome.storage.local.set({ settings: clean }); return clean; }
  };
  root.ClinkedinSettings = api;
  if (typeof module !== 'undefined') module.exports = api;
})(globalThis);
