(async function () {
  'use strict';
  const S = ClinkedinSettings, control = document.querySelector('#enabled'), status = document.querySelector('#page-status');
  let tabId;
  const autoplay = document.querySelector('#autoplay'), placeholders = document.querySelector('#placeholders');
  document.querySelector('#settings').addEventListener('click', () => chrome.runtime.openOptionsPage());
  function showSettings(settings) {
    control.checked = settings.enabled; autoplay.checked = settings.blockAutoplay;
    placeholders.checked = settings.showPlaceholders;
    document.querySelector('#filtered-state').textContent = settings.showPlaceholders ? 'Show bars' : 'Hide completely';
    document.querySelector('#state').textContent = settings.enabled ? 'Enabled' : 'Paused';
    const count = ['keywords', 'allowKeywords', 'authors', 'allowedAuthors', 'domains', 'hashtags'].reduce((n, key) => n + settings[key].length, 0) + Object.values(settings.types).filter(Boolean).length + Number(!!settings.minWords) + Number(!!settings.maxWords) + Number(settings.connectionFilter !== 'all');
    document.querySelector('#rules').textContent = count;
  }
  async function updateStats() {
    try {
      const data = await chrome.tabs.sendMessage(tabId, { action: 'stats' });
      if (!data?.inFeed) { status.textContent = 'Open the LinkedIn home feed to see filtering in action.'; return; }
      document.querySelector('#hidden').textContent = data.hidden;
      const version = chrome.runtime.getManifest().version;
      status.textContent = data.error || (data.version !== version ? 'This tab is running an older Clinkedin script. Refresh LinkedIn to apply the update.' : data.available ? `Connected · v${data.version} · ${data.scanned} loaded posts checked (${data.layout} layout). ${data.layoutHidden} layout elements hidden.` : `Connected · v${data.version} · No supported posts detected. Scroll once and click Check this page. If this persists, this feed layout needs an update.`);
      const reveal = document.querySelector('#reveal'); reveal.disabled = !data.available || !data.enabled;
      reveal.textContent = data.revealAll ? 'Apply filters again' : 'Reveal filtered posts';
    } catch { status.textContent = 'Clinkedin is not connected to this tab. Open the LinkedIn home feed. In chrome://extensions, reload Clinkedin and allow site access on LinkedIn, then refresh LinkedIn.'; }
  }
  document.querySelector('#rescan').addEventListener('click', async () => {
    try { await chrome.tabs.sendMessage(tabId, { action: 'rescan' }); setTimeout(updateStats, 250); }
    catch { await updateStats(); }
  });
  control.addEventListener('change', async () => {
    control.disabled = true;
    try { const latest = await S.load(); latest.enabled = control.checked; await S.save(latest); showSettings(latest); setTimeout(updateStats, 250); }
    catch { control.checked = !control.checked; status.textContent = 'Could not save. Please try again.'; }
    finally { control.disabled = false; }
  });
  autoplay.addEventListener('change', async () => {
    autoplay.disabled = true;
    try { const latest = await S.load(); latest.blockAutoplay = autoplay.checked; await S.save(latest); showSettings(latest); }
    catch { autoplay.checked = !autoplay.checked; status.textContent = 'Could not save. Try again.'; }
    finally { autoplay.disabled = false; }
  });
  placeholders.addEventListener('change', async () => {
    placeholders.disabled = true;
    try { const latest = await S.load(); latest.showPlaceholders = placeholders.checked; await S.save(latest); showSettings(latest); setTimeout(updateStats, 250); }
    catch { placeholders.checked = !placeholders.checked; status.textContent = 'Could not save. Try again.'; }
    finally { placeholders.disabled = false; }
  });
  document.querySelector('#reveal').addEventListener('click', async () => {
    try { await chrome.tabs.sendMessage(tabId, { action: 'reveal' }); setTimeout(updateStats, 250); }
    catch { status.textContent = 'Refresh your LinkedIn feed and reopen Clinkedin.'; }
  });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.settings) showSettings(S.normalize(changes.settings.newValue)); });
  try { showSettings(await S.load()); control.disabled = false; autoplay.disabled = false; placeholders.disabled = false; const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); tabId = tab?.id; await updateStats(); }
  catch { status.textContent = 'Could not load settings. Reopen the extension and try again.'; }
})();
