(function (root) {
  'use strict';
  const FEED = '[data-testid="mainFeed"], [role="feed"]';
  const LEGACY_POST = '.feed-shared-update-v2, .occludable-update, [data-urn^="urn:li:activity:"], [data-urn^="urn:li:aggregate:"], [data-id^="urn:li:activity:"]';
  const POST = `${LEGACY_POST}, [role="listitem"][componentkey^="update-card-focus"], [data-testid="mainFeed"] [role="listitem"]`;
  const BODY = '[data-testid="expandable-text-box"], .update-components-text, .feed-shared-update-v2__description, .feed-shared-text, .feed-shared-inline-show-more-text, [data-view-name="feed-commentary"]';
  const COMMENTS = '.comments-comments-list, .comments-comment-item, [data-testid*="commentList"], [data-testid*="comment-list"], [componentkey^="replaceableComment"]';
  const UI = '[data-clinkedin-ui]';
  const QUOTED = '.update-components-reshared-content, .feed-shared-update-v2__reshared-content, .update-components-mini-update-v2';
  const AUTHOR = '.update-components-actor__name, .update-components-actor__title, .feed-shared-actor__name, [data-view-name="feed-actor-name"]';
  const RELATION = '.dist-value, .update-components-actor__supplementary-actor-info, .feed-shared-actor__supplementary-actor-info, [data-testid="author-connection"]';
  const META = `${AUTHOR}, ${RELATION}, .update-components-header, .feed-shared-header, .update-components-actor__sub-description, .feed-shared-actor__sub-description`;
  const MEDIA = 'video, audio, iframe, canvas, [data-testid="video-player"], [data-component-type="VideoPlayer"], .video-js, .update-components-linkedin-video, .feed-shared-linkedin-video, .update-components-video';
  const text = node => node?.textContent?.replace(/\s+/gu, ' ').trim() || '';
  const cleanName = value => value.replace(/\s*[•·]\s*(?:1st|2nd|3rd\+?)\s*$/iu, '').trim();
  function outer(node) {
    let result = node?.closest(POST);
    if (result?.closest(COMMENTS)) result = result.closest(COMMENTS).parentElement?.closest(POST);
    if (!result) return null;
    for (let ancestor = result.parentElement?.closest(POST); ancestor; ancestor = ancestor.parentElement?.closest(POST)) result = ancestor;
    return result.closest(`main, [role="main"], ${FEED}`) ? result : null;
  }
  function posts(scope, deep = true) {
    const found = new Set();
    const add = node => { const card = outer(node); if (card) found.add(card); };
    if (scope.nodeType === 1) add(scope);
    if (deep) scope.querySelectorAll(POST).forEach(add);
    return found;
  }
  function authorOf(post) {
    const excluded = `${COMMENTS}, ${BODY}, ${QUOTED}, .update-components-header, .feed-shared-header`;
    const named = [...post.querySelectorAll(AUTHOR)].find(n => !n.closest(excluded));
    if (named) return cleanName(readText(named.querySelector('[aria-hidden="true"]') || named, `${RELATION}, .text-view-model__verified-icon`));
    const menu = [...post.querySelectorAll('button[aria-label]')].find(n => !n.closest(excluded) && /^Open control menu for post by\s+/i.test(n.getAttribute('aria-label')));
    if (menu) return menu.getAttribute('aria-label').replace(/^Open control menu for post by\s+/i, '').trim();
    for (const image of post.querySelectorAll('img[alt]')) {
      if (image.closest(excluded)) continue;
      const alt = image.getAttribute('alt').trim();
      const match = alt.match(/^View company:\s*(.+)$/i) || alt.match(/^View\s+(.+?)[’']s profile$/i);
      if (match) return match[1].trim();
    }
    const link = [...post.querySelectorAll('a[href*="/in/"], a[href*="/company/"]')].find(n => !n.closest(excluded) && text(n));
    return link ? cleanName(link.textContent.trim().split('\n')[0].trim()) : '';
  }
  function relationshipControl(node) {
    const control = node?.closest('button, [role="button"]');
    if (!control || control.closest(`${BODY}, ${COMMENTS}, ${MEDIA}, ${UI}`)) return false;
    return /^(?:[+✓✔−-]\s*)?(?:follow(?:ing)?|unfollow|stop following)(?:\s|$)/i.test((control.getAttribute('aria-label') || text(control)).trim());
  }
  function relationship(post, firstBody, author) {
    const excluded = `${BODY}, ${COMMENTS}, ${MEDIA}, ${UI}, .update-components-header, .feed-shared-header, ${QUOTED}`;
    const actor = [...post.querySelectorAll('.update-components-actor, .feed-shared-actor')].find(n => !n.closest(excluded));
    const scope = actor || post;
    const boundary = firstBody || post.querySelector(MEDIA);
    let connectionDegree = null, following = null;
    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_ELEMENT, {
      acceptNode(node) {
        if (node.matches(excluded) || (boundary && !(node.compareDocumentPosition(boundary) & Node.DOCUMENT_POSITION_FOLLOWING))) return NodeFilter.FILTER_REJECT;
        return node.matches(`${RELATION}, span, p, a, button, [role="button"], [aria-label]`) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });
    const authorName = root.ClinkedinEngine.fold(author);
    let node, visited = 0;
    while ((node = walker.nextNode()) && visited++ < 500) {
      const label = node.getAttribute('aria-label') || '';
      const value = node.children.length && !node.matches(`${RELATION}, a, button, [role="button"]`) ? '' : text(node);
      const degree = `${label} ${value}`.match(/(?:^|[•·\s])([123])(?:st|nd|rd)\+?(?:\s+degree(?:\s+connection)?)?\s*$/i);
      if (connectionDegree === null && degree) connectionDegree = Number(degree[1]);
      // Match a state label, never "followers", a headline, or post prose.
      for (const candidate of [label, value]) {
        const normalized = root.ClinkedinEngine.fold(candidate).replace(/^[+✓✔−-]\s*/, '');
        if (normalized === 'following' || normalized === 'unfollow' || normalized === `unfollow ${authorName}` || normalized === `stop following ${authorName}`) following = true;
        else if (following !== true && (normalized === 'follow' || normalized === `follow ${authorName}`)) following = false;
      }
    }
    return { connectionDegree, following };
  }
  function readText(node, skip) {
    // Do not clone cards: cloning a media element can initialize another player.
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode(item) {
        if (item.nodeType === 1) return item.matches(skip) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const chunks = []; let current, length = 0;
    while ((current = walker.nextNode()) && length < 120000) { chunks.push(current.textContent); length += current.textContent.length; }
    return chunks.join(' ').replace(/\s+/gu, ' ').trim();
  }
  function extract(post) {
    const E = root.ClinkedinEngine;
    const candidates = [...post.querySelectorAll(BODY)].filter(n => !n.closest(COMMENTS));
    const bodies = candidates.filter(n => !candidates.some(other => other !== n && other.contains(n)));
    const bodyText = node => readText(node, `${UI}, ${COMMENTS}, ${MEDIA}, button, script, style`);
    let body = bodies.map(bodyText).join('\n');
    if (!body) {
      body = readText(post, `${UI}, ${COMMENTS}, ${MEDIA}, .social-details-social-counts, .feed-shared-social-action-bar, .social-details-social-actions, .update-components-actor, .feed-shared-actor, .update-components-header, .feed-shared-header, button, script, style`);
    }
    const headerLabels = [];
    const firstBody = bodies[0];
    for (const node of post.querySelectorAll('p, span, .update-components-header, .feed-shared-header, .update-components-actor__sub-description, .feed-shared-actor__sub-description')) {
      if (node.closest(`${COMMENTS}, ${UI}, ${BODY}, ${MEDIA}`) || node.children.length || (firstBody && !(node.compareDocumentPosition(firstBody) & Node.DOCUMENT_POSITION_FOLLOWING))) continue;
      const label = text(node); if (label && label.length <= 200) headerLabels.push(E.fold(label));
      if (headerLabels.length >= 40) break;
    }
    const header = E.fold([text(post.querySelector('.update-components-header, .feed-shared-header')), ...headerLabels].join(' '));
    const context = E.fold(text(post.querySelector('.update-components-actor__sub-description, .feed-shared-actor__sub-description')));
    const links = [...post.querySelectorAll('a[href]')].filter(n => !n.closest(`${UI}, ${COMMENTS}, .update-components-actor, .feed-shared-actor`)).map(n => n.href);
    const types = [], has = selector => !!post.querySelector(selector);
    if (/\b(promoted|sponsored)\b/.test(`${context} ${header}`) || has('[data-ad-preview], [data-sponsored="true"], .feed-shared-actor__sponsored-indicator')) types.push('sponsored');
    if (/suggested|recommended for you|you might like/.test(header)) types.push('suggested');
    if (/reposted|reposts|shared this/.test(header) || has('.update-components-reshared-content, .feed-shared-update-v2__reshared-content')) types.push('reposts');
    if (/liked this|likes this|reacted to|commented on|celebrates this|loves this|supports this|finds this/.test(header)) types.push('reactions');
    if (has('.jobs-job-board-list, .update-components-job-card') || /\b(we.re hiring|i.m hiring|now hiring|join our team|hiring for)\b/i.test(body)) types.push('hiring');
    if (has('.update-components-celebration, .feed-shared-celebration') || /\b(starting a new position|work anniversary|celebrating \d+ years|started a new position)\b/i.test(body)) types.push('celebrations');
    if (has('.update-components-poll, .feed-shared-poll, [data-test-poll], [data-testid="poll"], [data-component-type="Poll"]')) types.push('polls');
    if (has('video, .update-components-linkedin-video, .feed-shared-linkedin-video, .update-components-video, [data-testid="video-player"]')) types.push('videos');
    if (has('.update-components-image, .feed-shared-image, [data-view-name="feed-image"], img[src*="feedshare"], img[src*="/feedshare-"], [data-testid="feed-image"]')) types.push('images');
    if (has('.update-components-document, .feed-shared-document, iframe[src*="document"], [data-testid="document-viewer"]')) types.push('documents');
    if (links.some(x => /linkedin\.com\/(pulse|newsletters)\//.test(x))) types.push('articles');
    if (has('.update-components-event') || links.some(x => /linkedin\.com\/events\//.test(x))) types.push('events');
    if (links.some(x => { try { const u = new URL(x); return /^https?:$/.test(u.protocol) && !/(^|\.)linkedin\.com$/.test(u.hostname); } catch { return false; } })) types.push('links');
    const author = authorOf(post);
    return { text: body, author, links, types, ...relationship(post, firstBody, author) };
  }
  const layoutSelectors = {
    hideRightRail: '.scaffold-layout__aside, aside[aria-label="Aside"], [data-testid="rightRail"], [data-testid="right-rail"]',
    hideLeftRail: '.scaffold-layout__sidebar, [data-testid="leftRail"], [data-testid="left-rail"]',
    hideComposer: '.share-box-feed-entry__closed-share-box, [data-testid="post-composer"], [componentkey^="share-box"]',
    hideMetrics: '.social-details-social-counts, [data-testid="social-counts"]',
    hidePostActions: '.feed-shared-social-action-bar, .social-details-social-actions, [data-testid="social-actions"]'
  };
  function layoutTargets(settings) {
    const targets = new Set();
    if (!settings.enabled) return targets;
    for (const [key, selector] of Object.entries(layoutSelectors)) if (settings.layout[key]) document.querySelectorAll(selector).forEach(n => targets.add(n));
    const feed = document.querySelector(FEED);
    if (feed && (settings.layout.hideLeftRail || settings.layout.hideRightRail)) {
      for (const aside of document.querySelectorAll('aside, [role="complementary"]')) {
        if (aside.contains(feed) || feed.contains(aside)) continue;
        // Semantic rails occur before/after the feed. No geometry reads or
        // temporarily showing hidden rails to measure them on every scan.
        const order = aside.compareDocumentPosition(feed);
        if ((settings.layout.hideLeftRail && (order & Node.DOCUMENT_POSITION_FOLLOWING)) || (settings.layout.hideRightRail && (order & Node.DOCUMENT_POSITION_PRECEDING))) targets.add(aside);
      }
    }
    if (settings.layout.hideComposer) {
      for (const button of document.querySelectorAll('button, [role="button"]')) {
        if (button.closest(`${POST}, nav, [data-testid="primary-nav"]`) || !/^start a post$/i.test(text(button))) continue;
        let card = button.closest('[data-component-type="Card"], section') || button.parentElement;
        if (card?.querySelector(FEED)) card = button;
        if (card) targets.add(card);
      }
    }
    if (settings.layout.hideMetrics || settings.layout.hidePostActions) {
      for (const post of posts(document)) {
        const actions = [];
        for (const node of post.querySelectorAll('button, [role="button"], p, span')) {
          if (node.closest(`${BODY}, ${COMMENTS}, ${MEDIA}, ${UI}`)) continue;
          const label = node.getAttribute('aria-label') || text(node);
          if (settings.layout.hideMetrics && /^(?:[\d,.]+[kmb]?\s+(?:reactions?|comments?|reposts?)|[\d,.]+\s+people reacted)(?:\s|$)/i.test(label)) targets.add(node);
          if (settings.layout.hidePostActions && node.matches('button, [role="button"]') && /^(?:like|comment|repost|send)(?:\s|$)/i.test(label)) actions.push(node);
        }
        for (const button of actions) {
          let row = button;
          for (let parent = button.parentElement, depth = 0; parent && parent !== post && depth < 4; parent = parent.parentElement, depth++) {
            if (parent.querySelector(`${BODY}, video`) || parent.matches(POST)) break;
            if (actions.filter(n => parent.contains(n)).length >= 3) { row = parent; break; }
          }
          targets.add(row);
        }
      }
    }
    return targets;
  }
  root.ClinkedinDOM = { POST, BODY, COMMENTS, FEED, META, MEDIA, outer, posts, extract, layoutTargets, relationshipControl };
})(globalThis);
