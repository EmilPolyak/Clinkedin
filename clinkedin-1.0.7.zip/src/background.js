'use strict';
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.action === 'openSettings' && sender.id === chrome.runtime.id) {
    chrome.runtime.openOptionsPage().then(() => reply({ ok: true }), () => reply({ ok: false }));
    return true;
  }
});
