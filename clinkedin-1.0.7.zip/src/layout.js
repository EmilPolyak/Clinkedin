(function (root) {
  'use strict';
  const D = root.ClinkedinDOM;
  const marks = new Map();
  let model = null;
  function mark(node, key, value = '') {
    if (!node || node.getAttribute(key) === value) return;
    if (!marks.has(node)) marks.set(node, new Map());
    if (!marks.get(node).has(key)) marks.get(node).set(key, node.getAttribute(key));
    node.setAttribute(key, value);
  }
  function clear() {
    for (const [node, attrs] of marks) for (const [key, value] of attrs) {
      if (value === null) node.removeAttribute(key); else node.setAttribute(key, value);
    }
    if (model) model.layout.style.removeProperty('--clinkedin-columns');
    marks.clear(); model = null;
  }
  function discover() {
    const feed = document.querySelector(D.FEED) || document.querySelector('.scaffold-layout__main') || D.posts(document).values().next().value?.closest('main, [role="main"]');
    if (!feed) return null;
    for (let branch = feed, depth = 0; branch?.parentElement && branch.parentElement !== document.body && depth < 10; branch = branch.parentElement, depth++) {
      const parent = branch.parentElement, style = getComputedStyle(parent);
      const grid = style.display.includes('grid');
      const flex = style.display.includes('flex') && style.flexDirection.startsWith('row');
      if (!grid && !flex) continue;
      const branches = [...parent.children].filter(n => !n.hasAttribute('data-clinkedin-ui') && !['SCRIPT', 'STYLE'].includes(n.tagName));
      if (branches.length < 2 || branches.length > 4 || branches.some(n => n.matches('nav, header, [data-testid="primary-nav"]'))) continue;
      const index = branches.indexOf(branch);
      if (index < 0) continue;
      // Read original track widths only when discovering a new layout, not on
      // each feed mutation. Never reveal a hidden rail to measure it.
      const widths = branches.map((node, i) => {
        if (i === index) return 0;
        return Math.max(160, Math.min(340, parseFloat(getComputedStyle(node).width) || (i < index ? 225 : 300)));
      });
      return { feed, layout: parent, column: branch, branches, index, widths, kind: grid ? 'grid' : 'flex' };
    }
    return null;
  }
  function apply(settings, hiddenTargets) {
    if (!settings.enabled || !settings.layout.wideFeed) { if (marks.size) clear(); return; }
    if (model && (!model.feed.isConnected || !model.column.contains(model.feed))) clear();
    if (!model) model = discover();
    if (!model) return;
    const { layout, column, branches, index, widths, kind } = model;
    mark(layout, 'data-clinkedin-wide-layout', kind);
    mark(column, 'data-clinkedin-wide-column');
    for (let node = model.feed; node && node !== column; node = node.parentElement) mark(node, 'data-clinkedin-feed-path');
    for (let parent = layout.parentElement, depth = 0; parent && parent !== document.body && depth < 5; parent = parent.parentElement, depth++) {
      if (parent.querySelector('nav, header, [data-testid="primary-nav"]')) break;
      mark(parent, 'data-clinkedin-wide-shell');
      if (parent.matches('main, [role="main"], .scaffold-layout')) break;
    }
    const tracks = [];
    for (let i = 0; i < branches.length; i++) {
      const branch = branches[i];
      if (i === index) { tracks.push('minmax(0, 1fr)'); continue; }
      const hide = i < index ? settings.layout.hideLeftRail : settings.layout.hideRightRail;
      if (hide) hiddenTargets.add(branch);
      else tracks.push(`${widths[i]}px`);
      mark(branch, 'data-clinkedin-side-column');
    }
    const columns = tracks.join(' ');
    if (layout.style.getPropertyValue('--clinkedin-columns') !== columns) layout.style.setProperty('--clinkedin-columns', columns);
  }
  root.ClinkedinLayout = { apply, clear };
})(globalThis);
