(function (root) {
  'use strict';
  function fold(text, sensitive = false) {
    const value = String(text || '').normalize('NFKC').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\s+/gu, ' ').trim();
    return sensitive ? value : value.toLocaleLowerCase();
  }
  function matches(text, phrase, settings) {
    const source = fold(text, settings.caseSensitive), needle = fold(phrase, settings.caseSensitive);
    if (!needle) return false;
    if (settings.matchMode !== 'whole') return source.includes(needle);
    let offset = 0, index;
    const word = char => !!char && /[\p{L}\p{N}_]/u.test(char);
    while ((index = source.indexOf(needle, offset)) !== -1) {
      const before = Array.from(source.slice(0, index)).pop();
      const after = Array.from(source.slice(index + needle.length))[0];
      if ((!word(Array.from(needle)[0]) || !word(before)) && (!word(Array.from(needle).pop()) || !word(after))) return true;
      offset = index + 1;
    }
    return false;
  }
  function host(value) {
    try { return new URL(value.includes('://') ? value : `https://${value}`).hostname.toLowerCase().replace(/^www\./, ''); } catch { return ''; }
  }
  function domainMatches(url, rule) {
    const actual = host(url), blocked = host(rule);
    return !!blocked && (actual === blocked || actual.endsWith(`.${blocked}`));
  }
  function evaluate(post, settings) {
    if (!settings.enabled) return [];
    const text = post.text || '';
    // Allow rules have explicit priority over every blocking rule.
    if (settings.allowedAuthors.some(x => fold(post.author) === fold(x)) || settings.allowKeywords.some(x => matches(text, x, settings))) return [];
    const reasons = [];
    if (settings.connectionFilter !== 'all') {
      const followed = post.following === true || settings.followedAuthors.some(x => fold(x) === fold(post.author));
      const degreeAllowed = post.connectionDegree === 1 || (settings.connectionFilter === 'first-second-followed' && post.connectionDegree === 2);
      const unknown = ![1, 2, 3].includes(post.connectionDegree);
      if (!followed && !degreeAllowed && !(unknown && settings.keepUnknownConnections)) {
        reasons.push(unknown ? 'Connection: author relationship not detected' : `Connection: ${post.connectionDegree === 2 ? '2nd' : '3rd+'} degree, not identified as followed`);
      }
    }
    for (const rule of settings.keywords) if (matches(text, rule, settings)) reasons.push(`Keyword: ${rule}`);
    for (const rule of settings.authors) if (fold(post.author) === fold(rule)) reasons.push(`Author: ${rule}`);
    const tags = [...text.matchAll(/#[\p{L}\p{N}_]+/gu)].map(x => fold(x[0]));
    for (const rule of settings.hashtags) if (tags.includes(fold(`#${rule.replace(/^#/, '')}`))) reasons.push(`Hashtag: #${rule.replace(/^#/, '')}`);
    for (const rule of settings.domains) if ((post.links || []).some(x => domainMatches(x, rule))) reasons.push(`Domain: ${rule}`);
    for (const [type, enabled] of Object.entries(settings.types)) if (enabled && post.types?.includes(type)) reasons.push(`Post type: ${type}`);
    const words = text.trim() ? text.trim().split(/\s+/u).length : 0;
    if (settings.minWords && words < settings.minWords) reasons.push(`Fewer than ${settings.minWords} words`);
    if (settings.maxWords && words > settings.maxWords) reasons.push(`More than ${settings.maxWords} words`);
    return reasons;
  }
  const api = { fold, matches, domainMatches, evaluate };
  root.ClinkedinEngine = api;
  if (typeof module !== 'undefined') module.exports = api;
})(globalThis);
