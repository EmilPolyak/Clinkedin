(function () {
  'use strict';
  if (globalThis.__clinkedinMedia) return;
  globalThis.__clinkedinMedia = true;
  const POLICY = 'clinkedin:autoplay-policy', REQUEST = 'clinkedin:autoplay-request';
  let revision = 0, policy;
  function publish() {
    if (typeof policy === 'boolean') document.dispatchEvent(new CustomEvent(POLICY, { detail: policy }));
  }
  function configure(settings) { policy = !!(settings.enabled && settings.blockAutoplay); publish(); }
  // The request handles either injection order between page and isolated worlds.
  document.addEventListener(REQUEST, publish);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings) { revision++; configure(ClinkedinSettings.normalize(changes.settings.newValue)); }
  });
  ClinkedinSettings.load().then(settings => { if (!revision) configure(settings); }).catch(() => {
    if (!revision) { policy = false; publish(); }
  });
})();
