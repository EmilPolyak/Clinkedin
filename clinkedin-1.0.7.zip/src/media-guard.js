(function () {
  'use strict';
  if (globalThis.__clinkedinMediaGuard) return;
  globalThis.__clinkedinMediaGuard = true;
  // This script runs in the page world before LinkedIn caches play(). Only the
  // autoplay boolean crosses from the isolated settings bridge; no rule lists do.
  const POLICY = 'clinkedin:autoplay-policy', REQUEST = 'clinkedin:autoplay-request';
  let enabled = true, configured = false;
  const originals = new Map(), gestures = new WeakMap(), manual = new WeakSet();
  const pending = new Map();
  const prototype = HTMLMediaElement.prototype;
  const nativePlay = prototype.play, nativePause = prototype.pause, nativeLoad = prototype.load;
  const PLAYER = '[data-testid="video-player"], [data-component-type="VideoPlayer"], .video-js, .update-components-linkedin-video, .feed-shared-linkedin-video, .update-components-video';
  function stop(video) { if (!video.paused) nativePause.call(video); }
  function permitted(video) {
    if (manual.has(video)) return true;
    if ((gestures.get(video) || 0) <= performance.now()) return false;
    gestures.delete(video); manual.add(video); return true;
  }
  function play(video, args) {
    if (enabled && !permitted(video)) {
      prepare(video);
      return Promise.reject(new DOMException('Automatic video playback is disabled by Clinkedin.', 'NotAllowedError'));
    }
    return nativePlay.apply(video, args);
  }
  prototype.play = function (...args) {
    if (!(this instanceof HTMLVideoElement)) return nativePlay.apply(this, args);
    if (configured) return play(this, args);
    // Wait for extension-local storage before the first page play() call. This
    // avoids a startup race without discarding autoplay when the option is off.
    return new Promise((resolve, reject) => {
      if (!pending.has(this)) pending.set(this, []);
      pending.get(this).push({ args, resolve, reject });
    });
  };
  function cancelPending(video) {
    for (const call of pending.get(video) || []) call.reject(new DOMException('Playback was interrupted.', 'AbortError'));
    pending.delete(video);
  }
  prototype.pause = function (...args) { cancelPending(this); return nativePause.apply(this, args); };
  prototype.load = function (...args) { cancelPending(this); return nativeLoad.apply(this, args); };
  function prepare(video) {
    if (!enabled || !(video instanceof HTMLVideoElement)) return;
    if (!originals.has(video)) originals.set(video, video.hasAttribute('autoplay'));
    if (video.hasAttribute('autoplay')) video.removeAttribute('autoplay');
    if (!manual.has(video)) stop(video);
  }
  function scan(node) {
    if (node.nodeType !== 1 && node.nodeType !== 9) return;
    if (node.nodeType === 1 && node.matches('video')) prepare(node);
    node.querySelectorAll('video').forEach(prepare);
  }
  function playback(event) {
    const video = event.target;
    if (!enabled || !(video instanceof HTMLVideoElement)) return;
    if (permitted(video)) return;
    prepare(video);
  }
  function intent(event) {
    if (!enabled || !event.isTrusted || (event.type === 'keydown' && ![' ', 'Enter', 'k', 'K'].includes(event.key))) return;
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    let video = target.closest('video');
    const control = target.closest('button, [role="button"]');
    if (!video && control && /\b(play|resume|replay)\b/i.test(`${control.getAttribute('aria-label') || ''} ${control.getAttribute('title') || ''} ${control.textContent || ''}`)) {
      const player = control.closest(PLAYER);
      if (player) video = player.querySelector('video');
      else for (let parent = control.parentElement, depth = 0; parent && depth < 5; parent = parent.parentElement, depth++) {
        const videos = parent.querySelectorAll('video');
        if (videos.length === 1) { video = videos[0]; break; }
        if (videos.length > 1) break;
      }
    }
    if (video) gestures.set(video, performance.now() + 2000);
  }
  function ended(event) {
    if (!(event.target instanceof HTMLVideoElement)) return;
    manual.delete(event.target); gestures.delete(event.target);
  }
  document.addEventListener('play', playback, true);
  document.addEventListener('playing', playback, true);
  document.addEventListener('loadstart', event => prepare(event.target), true);
  document.addEventListener('loadedmetadata', event => prepare(event.target), true);
  document.addEventListener('pause', ended, true);
  document.addEventListener('ended', ended, true);
  for (const type of ['pointerdown', 'click', 'keydown']) document.addEventListener(type, intent, true);
  const observer = new MutationObserver(mutations => {
    if (!enabled) return;
    for (const mutation of mutations) {
      if (mutation.type === 'attributes') prepare(mutation.target);
      else for (const node of mutation.addedNodes) scan(node);
    }
    for (const video of originals.keys()) if (!video.isConnected) { originals.delete(video); manual.delete(video); }
  });
  function configure(next) {
    const changed = !configured || next !== enabled;
    configured = true;
    clearTimeout(startupTimeout);
    enabled = next;
    if (changed) observer.disconnect();
    if (changed && enabled) {
      scan(document); observe();
    } else if (changed) {
      for (const [video, autoplay] of originals) {
        manual.delete(video); gestures.delete(video);
        if (autoplay && !video.hasAttribute('autoplay')) video.setAttribute('autoplay', '');
      }
      originals.clear();
    }
    for (const [video, calls] of pending) {
      pending.delete(video);
      for (const call of calls) {
        try { call.resolve(play(video, call.args)); } catch (error) { call.reject(error); }
      }
    }
  }
  function observe() {
    observer.observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['autoplay'] });
  }
  document.addEventListener(POLICY, event => {
    if (typeof event.detail === 'boolean') configure(event.detail);
  });
  // Remove native autoplay attributes as nodes arrive, including while storage
  // is loading. Restore original attributes if blocking is disabled.
  scan(document); observe();
  const startupTimeout = setTimeout(() => configure(false), 2000);
  document.dispatchEvent(new Event(REQUEST));
})();
